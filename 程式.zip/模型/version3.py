# version3.py
# -*- coding: utf-8 -*-
import os
import cv2
import numpy as np
import pickle
from collections import defaultdict
import random
import time

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer

import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, GlobalAveragePooling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import Callback, ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

from tqdm import tqdm

# ------------ 為了可重現性：固定隨機種子 ------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ============================================================
# 自訂 Callback：TQDM 每個 epoch 顯示 batch 進度
# ============================================================
class TQDMProgressBar(Callback):
    def on_train_begin(self, logs=None):
        self.epoch_pbar = None

    def on_epoch_begin(self, epoch, logs=None):
        steps = self.params.get("steps", None)
        if steps is None:
            return
        print(f"\n開始 Epoch {epoch + 1}/{self.params['epochs']}")
        self.epoch_pbar = tqdm(total=steps, desc=f"Epoch {epoch + 1}", ncols=100)
        self.start_time = time.time()

    def on_batch_end(self, batch, logs=None):
        if self.epoch_pbar is not None:
            self.epoch_pbar.update(1)

    def on_epoch_end(self, epoch, logs=None):
        if self.epoch_pbar is not None:
            self.epoch_pbar.close()
        elapsed = time.time() - self.start_time
        if logs is None:
            logs = {}
        loss = logs.get("loss", 0.0)
        acc = logs.get("accuracy", 0.0)
        val_loss = logs.get("val_loss", 0.0)
        val_acc = logs.get("val_accuracy", 0.0)
        print(
            f"Epoch {epoch+1} 結束："
            f"loss={loss:.4f} acc={acc:.4f} "
            f"val_loss={val_loss:.4f} val_acc={val_acc:.4f} "
            f"(耗時 {elapsed:.1f} 秒)"
        )

# ============================================================
# 資料路徑設定
# ============================================================
# PlantVillage 根目錄
DATA_DIR = R"D:\Python\Capstone_Project\PlantVillage"

# 固定類別順序的文字檔（放在同一個資料夾）
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LABEL_FILE = os.path.join(BASE_DIR, "class_names.txt")

# ============================================================
# 讀取圖片與標籤
# ============================================================
image_data = []
label_list = []

valid_exts = (".jpg", ".jpeg", ".png")

# 確保類別資料夾順序是固定的（字母排序）
categories = sorted(
    d for d in os.listdir(DATA_DIR)
    if os.path.isdir(os.path.join(DATA_DIR, d))
)

print("資料夾實際順序：", categories)

for category in categories:
    category_path = os.path.join(DATA_DIR, category)
    for img_file in os.listdir(category_path):
        if not img_file.lower().endswith(valid_exts):
            continue
        img_path = os.path.join(category_path, img_file)
        try:
            img = cv2.imdecode(np.fromfile(img_path, np.uint8), cv2.IMREAD_COLOR)
            if img is None:
                raise ValueError("圖片為空")
            img = cv2.resize(img, (128, 128))
            image_data.append(img)
            label_list.append(category)
        except Exception:
            print(f"無法讀取圖片：{img_path}")

print(f"成功讀取圖片總數：{len(image_data)}")
print(f"不同類別數量：{len(set(label_list))}")

# ============================================================
# Downsample 每類上限 1500
# ============================================================
MAX_PER_CLASS = 1500
indices_by_label = defaultdict(list)
for idx, lab in enumerate(label_list):
    indices_by_label[lab].append(idx)

selected_indices = []
for lab, idxs in indices_by_label.items():
    if len(idxs) > MAX_PER_CLASS:
        chosen = random.sample(idxs, MAX_PER_CLASS)
        print(f"{lab}: {len(idxs)} -> downsample 至 {MAX_PER_CLASS}")
    else:
        chosen = idxs
        print(f"{lab}: {len(idxs)} -> 保留全部")
    selected_indices.extend(chosen)

# 打散一下，避免同一類都集中在前面
random.shuffle(selected_indices)

image_data = [image_data[i] for i in selected_indices]
label_list = [label_list[i] for i in selected_indices]

print(f"\nDownsample 後圖片總數：{len(image_data)}")

# ============================================================
# 固定 Label 順序（使用 class_names.txt）+ 字串 label
# ============================================================
if not os.path.exists(LABEL_FILE):
    raise FileNotFoundError(f"找不到類別檔案：{LABEL_FILE}")

with open(LABEL_FILE, "r", encoding="utf-8") as f:
    class_names = [line.strip() for line in f.readlines() if line.strip()]

print("固定後的類別順序（來自 class_names.txt）：", class_names)

# 檢查 label_list 裡有沒有超出 txt 定義的類別
unknown_labels = sorted(set(label_list) - set(class_names))
if unknown_labels:
    print("⚠ 發現 txt 沒列出的類別：", unknown_labels)
    raise ValueError("資料夾與 class_names.txt 類別不一致，請先修正。")

# 直接用「字串」當 label，之後再轉 one-hot
labels_array = np.array(label_list)

# 建立 One-hot 編碼器（用字串類別）
label_binarizer = LabelBinarizer()
label_binarizer.fit(class_names)

# 儲存 label 對照表（給 APP 用）
with open(os.path.join(BASE_DIR, "label_transform.pkl"), "wb") as f:
    pickle.dump({"class_names": class_names}, f)

n_classes = len(class_names)
print("類別數量：", n_classes)


# ============================================================
# 轉 numpy + Train/Val split（用 numeric label stratify）
# ============================================================
# ============================================================
# 轉 numpy + MobileNetV2 官方前處理 + Train/Val split
# ============================================================

# 先轉成 float32，再用 MobileNetV2 的 preprocess_input
image_data = np.array(image_data, dtype="float32")
image_data = preprocess_input(image_data)  # 會把 0~255 映射到 [-1, 1]

# 用「字串 label」做 stratify，避免 index 對不起來
X_train, X_val, y_train_str, y_val_str = train_test_split(
    image_data,
    labels_array,
    test_size=0.2,
    random_state=SEED,
    stratify=labels_array,
)

# 轉成 one-hot
y_train = label_binarizer.transform(y_train_str)
y_val = label_binarizer.transform(y_val_str)

print("Train shape:", X_train.shape, y_train.shape)
print("Val   shape:", X_val.shape, y_val.shape)

# 順便看一下各類別分佈
unique_train, counts_train = np.unique(y_train_str, return_counts=True)
print("Train 每類數量：", dict(zip(unique_train, counts_train)))
unique_val, counts_val = np.unique(y_val_str, return_counts=True)
print("Val   每類數量：", dict(zip(unique_val, counts_val)))


print("Train shape:", X_train.shape, y_train.shape)
print("Val   shape:", X_val.shape, y_val.shape)

# ============================================================
# Augmentation
# ============================================================
train_datagen = ImageDataGenerator(
    rotation_range=30,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.3,
    brightness_range=(0.6, 1.4),
    horizontal_flip=True,
    fill_mode="nearest",
)

val_datagen = ImageDataGenerator()

train_generator = train_datagen.flow(X_train, y_train, batch_size=32, shuffle=True)
val_generator = val_datagen.flow(X_val, y_val, batch_size=32, shuffle=False)

# ============================================================
# 建立 MobileNetV2 模型
# ============================================================
def build_model(base_trainable=False, lr=1e-3):
    base_model = MobileNetV2(
        include_top=False,
        weights="imagenet",
        input_shape=(128, 128, 3),
    )

    base_model.trainable = base_trainable

    model = Sequential(
        [
            base_model,
            GlobalAveragePooling2D(),
            Dropout(0.5),
            Dense(128, activation="relu"),
            Dropout(0.3),
            Dense(n_classes, activation="softmax"),
        ]
    )

    model.compile(
        optimizer=Adam(learning_rate=lr),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model

# ============================================================
# 第一階段：Warm-up（只訓練 head）
# ============================================================
print("\n======== 第 1 階段：Warm-up（凍結 backbone） ========")
model = build_model(base_trainable=False, lr=1e-3)
model.summary()

callbacks_stage1 = [
    TQDMProgressBar(),
    ModelCheckpoint(
        os.path.join(BASE_DIR, "stage1_best.h5"),
        save_best_only=True,
        monitor="val_accuracy",
        mode="max",
    ),
    EarlyStopping(patience=3, restore_best_weights=True, monitor="val_accuracy"),
]

history1 = model.fit(
    train_generator,
    validation_data=val_generator,
    epochs=8,
    callbacks=callbacks_stage1,
)

# ============================================================
# 第二階段：Fine-tune（解凍最後 60 層）
# ============================================================
print("\n======== 第 2 階段：Fine-tune（解凍 backbone 後 60 層） ========")

# 取得 base_model（Sequential 的第一層）
base_model = model.layers[0]

# 先全部解凍
base_model.trainable = True

# 只保留最後 60 層可以訓練
for layer in base_model.layers[:-60]:
    layer.trainable = False

print(f"Total layers in base_model: {len(base_model.layers)}")
trainable_count = sum(1 for l in base_model.layers if l.trainable)
print(f"Trainable layers in base_model(after unfreeze): {trainable_count}")

# 重新 compile，學習率調低
model.compile(
    optimizer=Adam(learning_rate=1e-5),
    loss="categorical_crossentropy",
    metrics=["accuracy"],
)

callbacks_stage2 = [
    TQDMProgressBar(),
    ModelCheckpoint(
        os.path.join(BASE_DIR, "best_model.h5"),
        save_best_only=True,
        monitor="val_accuracy",
        mode="max",
    ),
    EarlyStopping(patience=5, restore_best_weights=True, monitor="val_accuracy"),
    ReduceLROnPlateau(
        monitor="val_loss",
        factor=0.5,
        patience=2,
        verbose=1,
        min_lr=1e-7,
    ),
]

history2 = model.fit(
    train_generator,
    validation_data=val_generator,
    epochs=50,
    callbacks=callbacks_stage2,
)

print("\n訓練完成，最終模型已儲存為 best_model.h5")
