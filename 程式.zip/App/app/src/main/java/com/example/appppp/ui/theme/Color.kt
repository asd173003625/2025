package com.example.appppp.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF4CAF50)   // 主色
val SecondaryGreen = Color(0xFFA5D6A7) // 次色
val BackgroundTint = Color(0xFFF9FFF9) // 背景
val TextDeepGreen = Color(0xFF2E7D32)  // 文字深綠
