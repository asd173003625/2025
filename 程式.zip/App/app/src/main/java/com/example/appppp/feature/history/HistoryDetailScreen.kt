package com.example.appppp.feature.history

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.appppp.data.model.HistoryItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryDetailScreen(
    item: HistoryItem,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val viewModel: HistoryViewModel = viewModel()


    val diseaseEnglishMap = mapOf(
        "健康" to "healthy",
        "鎮斑病毒病" to "mosaic_virus",
        "黃化捲葉病" to "YellowLeaf_Curl_Virus",
        "葉黴病" to "Leaf_Mold",
        "晚疫病" to "Late_blight",
        "早疫病" to "Early_blight",
        "葉斑病" to "Septoria_leaf_spot",
        "斑枯病" to "Target_Spot",
        "二斑葉蟎" to "Spider_mites_Two_spotted_spider_mite",
        "細菌性斑點病" to "Bacterial_spot"
    )

    val englishName = diseaseEnglishMap[item.diseaseType] ?: ""

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("紀錄詳情") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxSize(),
            horizontalAlignment = Alignment.Start
        ) {


            Image(
                painter = rememberAsyncImagePainter(Uri.parse(item.imageUri)),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop
            )

            Spacer(Modifier.height(20.dp))


            Text(
                text = "作物名稱：${item.cropName}",
                fontSize = 22.sp,
                color = Color(0xFF2E7D32)
            )

            Spacer(Modifier.height(14.dp))


            Text(
                text = "病害類型：${item.diseaseType} ($englishName)",
                fontSize = 20.sp,
                color = Color(0xFF2E7D32)
            )

            Spacer(Modifier.height(18.dp))


            Text(
                text = "防治建議：",
                fontSize = 18.sp,
                color = Color(0xFF388E3C)
            )
            Spacer(Modifier.height(6.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(start = 12.dp)
            ) {
                item.suggestion.split("\n").forEach { line ->
                    if (line.isNotBlank()) {
                        Text(
                            text = line.trim(),
                            fontSize = 16.sp,
                            color = Color(0xFF388E3C)
                        )
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            Text(
                text = "紀錄時間：${item.date}",
                fontSize = 14.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.weight(1f))


            Button(
                onClick = {
                    viewModel.delete(item)
                    Toast.makeText(context, "🗑️ 紀錄已刪除", Toast.LENGTH_SHORT).show()
                    onBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD32F2F),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("刪除此紀錄", fontSize = 18.sp)
            }
        }
    }
}

