package com.example.appppp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.appppp.feature.history.HistoryScreen
import com.example.appppp.feature.history.HistoryDetailScreen
import com.example.appppp.feature.history.HistoryViewModel
import com.example.appppp.feature.home.HomeScreen
import com.example.appppp.feature.result.ResultScreen
import com.example.appppp.feature.upload.UploadScreen
import com.example.appppp.ui.theme.AppTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot() {
    AppTheme {
        val nav = rememberNavController()

        NavHost(navController = nav, startDestination = "home") {

            composable("home") {
                HomeScreen(
                    onGoUpload = { nav.navigate("upload") },
                    onGoHistory = { nav.navigate("history") }
                )
            }


            composable("upload") {
                UploadScreen(
                    onBack = { nav.popBackStack() },
                    onGoResult = { imageUri ->
                        nav.navigate("result?imageUri=$imageUri")
                    }
                )
            }


            composable(
                route = "result?imageUri={imageUri}",
                arguments = listOf(
                    navArgument("imageUri") { type = NavType.StringType; nullable = true }
                )
            ) {
                val uri = it.arguments?.getString("imageUri")
                ResultScreen(
                    onBack = { nav.popBackStack() },
                    imageUri = uri,
                    navController = nav
                )
            }


            composable("history") {
                HistoryScreen(
                    onBack = { nav.popBackStack() },
                    onItemClick = { item ->

                        nav.navigate("history_detail/${item.id}")
                    }
                )
            }


            composable(
                route = "history_detail/{id}",
                arguments = listOf(
                    navArgument("id") { type = NavType.IntType }
                )
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getInt("id") ?: 0
                val viewModel = viewModel<HistoryViewModel>()
                val historyList = viewModel.allHistory.collectAsState(initial = emptyList())
                val item = historyList.value.find { it.id == id }

                if (item != null) {
                    HistoryDetailScreen(
                        item = item,
                        onBack = { nav.popBackStack() }
                    )
                }
            }
        }
    }
}
