package com.example.appppp.feature.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.appppp.data.model.HistoryItem
import com.example.appppp.data.repository.HistoryRepository
import kotlinx.coroutines.launch

class HistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = HistoryRepository(application)
    val allHistory = repo.getAll()

    fun insert(item: HistoryItem) = viewModelScope.launch {
        repo.insert(item)
    }


    fun deleteAll() = viewModelScope.launch {
        repo.deleteAll()
    }
    fun delete(item: HistoryItem) = viewModelScope.launch {
        repo.delete(item)
    }

}

