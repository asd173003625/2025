package com.example.appppp.data

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.nio.ByteBuffer

class TFLiteHelper(context: Context) {
    private val interpreter: Interpreter

    private val labelMap = listOf(
        "番茄細菌性斑點病 (Tomato__Bacterial_spot)",
        "番茄早疫病 (Tomato__Early_blight)",
        "健康番茄 (Tomato__healthy)",
        "番茄晚疫病 (Tomato__Late_blight)",
        "番茄葉黴病 (Tomato__Leaf_Mold)",
        "番茄嵌紋病毒 (Tomato__mosaic_virus)",
        "番茄白斑病 (Tomato__Septoria_leaf_spot)",
        "番茄紅蜘蛛 (Tomato__Spider_mites_Two_spotted_spider_mite)",
        "番茄靶斑病 (Tomato__Target_Spot)",
        "番茄黃化捲葉病毒 (Tomato__YellowLeaf_Curl_Virus)"
    )

    init {
        val assetFileDescriptor = context.assets.openFd("plant_disease_model.tflite")
        val inputStream = assetFileDescriptor.createInputStream()
        val model = inputStream.readBytes()
        val buffer = ByteBuffer.allocateDirect(model.size)
        buffer.put(model)
        interpreter = Interpreter(buffer)
    }


    fun classifyWithConfidence(bitmap: Bitmap): Pair<String, Float> {
        val image = TensorImage.fromBitmap(bitmap)
        val output = TensorBuffer.createFixedSize(intArrayOf(1, 10), org.tensorflow.lite.DataType.FLOAT32)
        interpreter.run(image.buffer, output.buffer.rewind())
        val probs = output.floatArray
        val index = probs.indices.maxByOrNull { probs[it] } ?: -1
        val label = if (index in labelMap.indices) labelMap[index] else "未知"
        val confidence = if (index >= 0) probs[index] else 0f
        return Pair(label, confidence)
    }
}
