package com.example.appppp.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.googlefonts.GoogleFont.Provider
import androidx.compose.ui.unit.sp
import com.example.appppp.R

// Google Fonts 設定
private val provider = Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs // ✅ 改這樣！
)
private val Poppins = FontFamily(
    Font(googleFont = GoogleFont("Poppins"), fontProvider = provider)
)
private val NotoSansTC = FontFamily(
    Font(googleFont = GoogleFont("Noto Sans TC"), fontProvider = provider)
)

val AppTypography = Typography(
    displayLarge = TextStyle( // App 大標題
        fontFamily = Poppins,
        fontSize = 28.sp,
        lineHeight = 34.sp
    ),
    titleLarge = TextStyle( // 區塊標題
        fontFamily = Poppins,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    bodyLarge = TextStyle( // 內文
        fontFamily = NotoSansTC,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    labelLarge = TextStyle( // 按鈕字
        fontFamily = Poppins,
        fontSize = 16.sp
    )
)
