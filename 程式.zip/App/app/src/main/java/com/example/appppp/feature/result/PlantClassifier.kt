package com.example.appppp.feature.result

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class PlantClassifier(private val context: Context) {

    private val interpreter: Interpreter
    private val labels: List<String>
    private val imageSize = 128

    init {

        val modelBytes = context.assets.open("plant_disease_model.tflite").readBytes()


        val buffer = ByteBuffer.allocateDirect(modelBytes.size)
        buffer.order(ByteOrder.nativeOrder())
        buffer.put(modelBytes)
        interpreter = Interpreter(buffer)


        labels = loadLabels()
    }


    private fun loadLabels(): List<String> {
        val input = context.assets.open("labels.txt")
        val reader = BufferedReader(InputStreamReader(input))
        return reader.readLines()
    }


    fun classify(bitmap: Bitmap): Pair<String, Float> {


        val resized = Bitmap.createScaledBitmap(bitmap, imageSize, imageSize, false)


        val inputBuffer = convertBitmapToBuffer(resized)


        val output = Array(1) { FloatArray(labels.size) }


        interpreter.run(inputBuffer, output)


        val scores = output[0]
        val maxIndex = scores.indices.maxByOrNull { scores[it] } ?: 0
        val confidence = scores[maxIndex]

        return Pair(labels[maxIndex], confidence)
    }


    private fun convertBitmapToBuffer(bitmap: Bitmap): FloatBuffer {
        val floatData =
            FloatBuffer.allocate(imageSize * imageSize * 3)  // RGB

        for (y in 0 until imageSize) {
            for (x in 0 until imageSize) {

                val pixel = bitmap.getPixel(x, y)

                val r = (pixel shr 16 and 0xFF) / 255f
                val g = (pixel shr 8 and 0xFF) / 255f
                val b = (pixel and 0xFF) / 255f

                floatData.put(r)
                floatData.put(g)
                floatData.put(b)
            }
        }

        floatData.rewind()
        return floatData
    }
}
