package com.example.appppp.data.repository

import android.app.Application
import com.example.appppp.data.db.AppDatabase
import com.example.appppp.data.model.HistoryItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext


class HistoryRepository(application: Application) {
    private val dao = AppDatabase.getDatabase(application).historyDao()

    fun getAll() = dao.getAll()

    suspend fun insert(item: HistoryItem) {
        withContext(Dispatchers.IO) {
            dao.insert(item)
        }
    }

    suspend fun deleteAll() {
        withContext(Dispatchers.IO) {
            dao.deleteAll()
        }
    }
    suspend fun delete(item: HistoryItem) = dao.delete(item)

}

