package com.example.appppp.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.appppp.data.model.HistoryItem
import kotlinx.coroutines.flow.Flow
import androidx.room.Delete
@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(history: HistoryItem)

    @Query("SELECT * FROM history ORDER BY id DESC")
    fun getAll(): Flow<List<HistoryItem>>

    @Query("DELETE FROM history")
    suspend fun deleteAll()

    @Delete
    suspend fun delete(item: HistoryItem)

}