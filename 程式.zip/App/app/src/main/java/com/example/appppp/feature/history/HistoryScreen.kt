package com.example.appppp.feature.history

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.appppp.data.model.HistoryItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    onBack: () -> Unit,
    onItemClick: (HistoryItem) -> Unit
) {
    val viewModel: HistoryViewModel = viewModel()
    val historyList = viewModel.allHistory.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("歷史紀錄") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.deleteAll() }) {
                        Icon(Icons.Filled.Delete, contentDescription = "清除紀錄")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (historyList.value.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("目前沒有任何紀錄", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(historyList.value.reversed()) { item ->
                    HistoryCard(item, onClick = { onItemClick(item) })
                }
            }
        }
    }
}

@Composable
fun HistoryCard(
    item: HistoryItem,
    onClick: () -> Unit
) {

    val (zhName, enName) = convertDiseaseName(item.diseaseType)

    val suggestionList = formatSuggestions(item.suggestion)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 4.dp),
        color = Color(0xFFF9F9F9),
        tonalElevation = 4.dp,
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 6.dp
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            // 圖片
            if (item.imageUri.isNotEmpty()) {
                Image(
                    painter = rememberAsyncImagePainter(Uri.parse(item.imageUri)),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFEFEFEF)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFEFEFEF)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("無圖片", color = Color.Gray)
                }
            }


            Text(
                text = "作物名稱：${item.cropName}",
                style = MaterialTheme.typography.titleMedium.copy(color = Color(0xFF2E7D32))
            )


            Text(
                text = "病害類型：${zhName}（${enName}）",
                style = MaterialTheme.typography.titleSmall.copy(color = Color(0xFF388E3C))
            )

            Text(
                text = "防治建議：",
                style = MaterialTheme.typography.titleSmall.copy(color = Color(0xFF2E7D32))
            )


            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                suggestionList.forEachIndexed { index, s ->
                    Text("${index + 1}. $s", style = MaterialTheme.typography.bodySmall)
                }
            }


            Text(
                text = "紀錄時間：${item.date}",
                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
            )
        }
    }
}


fun convertDiseaseName(raw: String): Pair<String, String> {

    return when (raw) {

        "Tomato__Late_blight", "晚疫病" -> "晚疫病" to "Late blight"
        "Tomato__Early_blight", "早疫病" -> "早疫病" to "Early blight"
        "Tomato__Leaf_Mold", "葉黴病" -> "葉黴病" to "Leaf mold"
        "Tomato__Bacterial_spot", "細菌性斑點病" -> "細菌性斑點病" to "Bacterial spot"
        "Tomato__mosaic_virus", "番茄莫賽克病毒" -> "番茄莫賽克病毒" to "Mosaic virus"
        "Tomato__YellowLeaf_Curl_Virus", "黃化捲葉病毒" -> "黃化捲葉病毒" to "Yellow leaf curl virus"
        "Tomato__Septoria_leaf_spot", "尾孢葉斑病" -> "尾孢葉斑病" to "Septoria leaf spot"
        "Tomato__Spider_mites_Two_spotted_spider_mite", "二點葉蟎危害" -> "二點葉蟎危害" to "Spider mites"
        "Tomato__Target_Spot", "靶斑病" -> "靶斑病" to "Target spot"
        "Tomato__healthy", "健康" -> "健康" to "Healthy"

        else -> raw to raw
    }
}

fun formatSuggestions(raw: String): List<String> {
    return raw
        .replace("。", "。|")
        .split("|")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .map {
            it.replace(Regex("^\\d+\\."), "")
                .trim()
        }
}
