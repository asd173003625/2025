package com.example.appppp.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val imageUri: String,
    val cropName: String,
    val diseaseType: String,
    val suggestion: String,
    val date: String
)
