package com.example.appppp.feature.result

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.appppp.data.model.HistoryItem
import com.example.appppp.feature.history.HistoryViewModel
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.ui.text.buildAnnotatedString


fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap {
    val rawBitmap =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.isMutableRequired = true
            }
        } else {
            context.contentResolver.openInputStream(uri).use { input ->
                BitmapFactory.decodeStream(input)
            }
        }

    return rawBitmap.copy(Bitmap.Config.ARGB_8888, true)
}


val diseaseNameMap = mapOf(
    "Bacterial_spot" to "細菌性斑點病",
    "Early_blight" to "早疫病",
    "Late_blight" to "晚疫病",
    "Leaf_Mold" to "葉黴病",
    "Septoria_leaf_spot" to "葉斑病",
    "mosaic_virus" to "鑲嵌病毒病",
    "Spider_mites_Two_spotted_spider_mite" to "葉蟎危害",
    "Target_Spot" to "靶斑病",
    "YellowLeaf_Curl_Virus" to "黃化捲葉病毒",
    "healthy" to "健康"
)


fun getSuggestion(diseaseChinese: String): String {
    return when (diseaseChinese) {
        "細菌性斑點病" -> "1.噴銅劑：抑制細菌，避免擴散。\n2.根部灌溉：減少葉面濕度。\n3.清除病葉：移除感染源。"
        "早疫病" -> "1.噴百菌清：預防初期感染。\n2.摘病葉：減少病源擴散。\n3.改滴灌：避免泥水濺葉。"
        "晚疫病" -> "1.提前噴藥：避免快速蔓延。\n2.拔病株：減少病原。\n3.通風排水：降低濕度。"
        "葉黴病" -> "1.控濕通風：阻病菌繁殖。\n2.清病葉消毒：減孢子傳播。\n3.噴藥：用百菌清等保護藥。"
        "葉斑病" -> "1.用抗病種苗：減少帶毒率。\n2.手部器具消毒：防接觸傳播。\n3.拔病株：切斷傳染鏈。"
        "鑲嵌病毒病" -> "1.噴百菌清：預防感染。\n2.清除病葉：減孢子來源。\n3.輪作除草：減低土壤殘留。"
        "葉蟎危害" -> "1.噴專用殺蟎劑：快速殺蟲。\n2.放捕食蟎：生物防治。\n3.水柱沖洗葉背：物理驅除。"
        "靶斑病" -> "1.定期噴藥：保護葉片。\n2.疏植修枝：通風防潮。\n3.輪作清園：斷開病源。"
        "黃化捲葉病毒" -> "1.種抗病品種：減輕發病。\n2.防白粉蝨：藥劑+銀膜。\n3.拔病株：移除傳染源。"
        "健康" -> "作物健康，維持現有栽培方式即可。"
        else -> "請參考農作物病蟲害防治手冊。"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    onBack: () -> Unit,
    imageUri: String?,
    navController: NavController
) {
    var isLoading by remember { mutableStateOf(true) }
    var cropName by remember { mutableStateOf("Tomato") }
    var diseaseEnglish by remember { mutableStateOf("") }
    var diseaseChinese by remember { mutableStateOf("") }
    var confidence by remember { mutableStateOf(0f) }
    var suggestion by remember { mutableStateOf("") }

    val context = LocalContext.current
    val viewModel: HistoryViewModel = androidx.lifecycle.viewmodel.compose.viewModel()

    LaunchedEffect(imageUri) {
        if (imageUri == null) return@LaunchedEffect

        try {
            isLoading = true
            val uri = Uri.parse(imageUri)

            val bitmap = loadBitmapFromUri(context, uri)
            val classifier = PlantClassifier(context)
            val (label, conf) = classifier.classify(bitmap)

            val parts = label.split("__")
            cropName = parts.getOrNull(0) ?: "Tomato"
            diseaseEnglish = parts.getOrNull(1) ?: "Unknown"

            diseaseChinese = diseaseNameMap[diseaseEnglish] ?: "未知病害"
            confidence = conf
            suggestion = getSuggestion(diseaseChinese)

        } catch (e: Exception) {
            Toast.makeText(context, "辨識失敗：${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            isLoading = false
        }
    }

    val confidenceColor = when {
        confidence >= 0.80f -> Color(0xFF2E7D32)
        confidence < 0.40f -> Color(0xFFD32F2F)
        else -> Color(0xFFF9A825)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("辨識結果") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            if (imageUri != null) {
                Image(
                    painter = rememberAsyncImagePainter(Uri.parse(imageUri)),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                )
            }

            if (isLoading) {
                CircularProgressIndicator()
                Text("辨識中，請稍候…")
            } else {

                val cleaned = suggestion.replace("\n\n", "\n")
                val lines = cleaned.split("\n").filter { it.isNotBlank() }
                val indent = "　　　　　" // 12 全形空白

                val suggestionText = buildAnnotatedString {
                    append("防治建議：${lines.first()}\n")
                    lines.drop(1).forEach { append(indent + it + "\n") }
                }


                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.Start,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("作物名稱：$cropName")
                    Text("病害類型：$diseaseChinese ($diseaseEnglish)")

                    Text(
                        "信心分數：${"%.2f".format(confidence * 100)}%",
                        color = confidenceColor,
                        style = MaterialTheme.typography.bodyLarge
                    )

                    Text(
                        text = suggestionText,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }

                Button(
                    onClick = {
                        val item = HistoryItem(
                            imageUri = imageUri ?: "",
                            cropName = cropName,
                            diseaseType = diseaseChinese,
                            suggestion = cleaned,
                            date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date())
                        )
                        viewModel.insert(item)
                        Toast.makeText(context, "已儲存紀錄", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("儲存紀錄")
                }

                Button(
                    onClick = {
                        navController.navigate("home") {
                            popUpTo("home") { inclusive = true }
                            launchSingleTop = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF81C784),
                        contentColor = Color.White
                    )
                ) {
                    Text("🏠 返回首頁")
                }
            }
        }
    }
}
